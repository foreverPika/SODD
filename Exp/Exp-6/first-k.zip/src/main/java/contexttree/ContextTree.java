package contexttree;

import sodd.AttributeSet;
import util.Timer;

public class ContextTree {
    public ContextNode root;
    public AttributeSet schema;//构成context的全部属性
    public int columnNum;
    public util.Timer timer;
    public static long expandTime=0;
    public static long testTime = 0;
    public boolean isComplete;
    public byte completeLevel;

    public ContextTree(AttributeSet schema, int columnNum) {
        this.root = new ContextNode();
        this.schema = schema;
        this.columnNum = columnNum;
        this.timer = new Timer();
        this.isComplete = false;
        this.completeLevel = -1;
    }

    public int findContext(AttributeSet context) {//找到准确的context，0为non，1为valid，2为待验证，3为不存在
        return findContext2(root, context);
    }

    private int findContext2(ContextNode root, AttributeSet context) {
        if (context.isEmpty()) {
            return root.isValid;
        }
        if (root.nextNodes.isEmpty()) {
            return 3;
        }
        int contextAttribute = context.getFirstAttribute();
        for (ContextNode contextNode : root.nextNodes) {
            if (contextNode.attribute == contextAttribute) {
                return findContext2(contextNode, context.deleteAttribute(contextAttribute));
            }
        }
        return 3;
    }

    public int addNonNodeOld(AttributeSet context) {//添加为non的结点,返回插入的新ocd个数
//        if(isComplete){
//            System.out.println("有用有用有用有用有用");
//            return 0;
//        }
//        int contextSize = context.getSize();
//        if(contextSize<=completeLevel){
//            return 0;
//        }
        if (context.isEmpty()) {//根节点为nonNode
            if (root.isValid != 0) {//根结点已经是nonNode，则不用扩展根节点
                root.isValid = 0;
                expandNode(root);
                return 1;
            }
            return 0;
        } else {
            //nonNode不是根节点，继续搜索
            root.isValid = 0;
            return addNonNode2(root, context);
//            return addNonNode2(root, context,0,context.getSize());

        }
    }
    private int addNonNode2(ContextNode root, AttributeSet context) {
        int count = 0;
        if (root.nextNodes.isEmpty()) {//下一个节点为空，就新建节点
            expandNode(root);
            ++count;
            root.isValid = 0;
        }
        //下一个节点不为空，访问节点
        for (ContextNode nextNode : root.nextNodes) {
            int firstAttribute = context.getFirstAttribute();
            if (nextNode.attribute == firstAttribute) {//匹配到context的第一个属性
                if (context.getSize() == 1) {//只剩下一个属性，则直接找到，设为0
                    if (nextNode.isValid != 0) {//该结点为候选ocd，改为nonocd,扩展结点
                        nextNode.isValid = 0;
                        expandNode(nextNode);
                        ++count;
//                        return count;
                    }
                    //该结点不为候选结点（已经验证错误和正确），直接返回
                    return count;
                } else {//context还有2个以上的属性，则删掉第一个属性，继续查找下一个节点和旁边的结点,并把路径节点标记为non 2  45
                    root.isValid = 0;

                    context = context.deleteAttribute(firstAttribute);
                    count += addNonNode2(nextNode, context);
                }
            }//没有匹配到context的第一个属性，继续看下一个结点
        }
        return count;
    }
    public int addNonNode(AttributeSet context) {
        return addNonNodeNew(root,context);
    }
    private int addNonNodeNew(ContextNode root, AttributeSet context) {
        int count = 0;
        if (root.nextNodes.isEmpty()) {//下一个节点为空，就新建节点
            expandNode(root);
            ++count;
            root.isValid = 0;
        }
        if(context.isEmpty()){
            return count;
        }
        int firstAttribute = context.getFirstAttribute();
        //下一个节点不为空，访问节点
        for (ContextNode nextNode : root.nextNodes) {

            if (nextNode.attribute == firstAttribute) {//匹配到context的第一个属性
                context = context.deleteAttribute(firstAttribute);

                count += addNonNodeNew(nextNode, context);
                if(context.isEmpty()){
                    return count;
                }else{
                    firstAttribute = context.getFirstAttribute();
                }
            }//没有匹配到context的第一个属性，继续看下一个结点
        }
        return count;
    }
    private int addNonNode2(ContextNode root, AttributeSet context, int level,int contetxSize) {
        int count = 0;
        if (root.nextNodes.isEmpty()) {//下一个节点为空，就新建节点
            expandNode(root);
            ++count;
            root.isValid = 0;
        }
        //下一个节点不为空，访问节点
        for (ContextNode nextNode : root.nextNodes) {
            int firstAttribute = context.getFirstAttribute();
            if (nextNode.attribute == firstAttribute) {//匹配到context的第一个属性
                if (context.getSize() == 1) {//只剩下一个属性，则直接找到，设为0
                    if (nextNode.isValid != 0) {//该结点为候选ocd，改为nonocd,扩展结点
                        nextNode.isValid = 0;
                        expandNode(nextNode);
                        ++count;
//                        return count;
                    }
                    //该结点不为候选结点（已经验证错误和正确），直接返回
                    return count;
                } else {//context还有2个以上的属性，则删掉第一个属性，继续查找下一个节点和旁边的结点,并把路径节点标记为non 2  45
                    root.isValid = 0;

                    context = context.deleteAttribute(firstAttribute);
                    --contetxSize;
                    count += addNonNode2(nextNode, context,level + 1,contetxSize);
                    if(contetxSize+level+1<=completeLevel){
//                        System.out.println("返回");
                        return count;
                    }
                }
            }//没有匹配到context的第一个属性，继续看下一个结点
        }
        return count;
    }

    /**
     * 扩展节点
     *
     * @param node 要扩展的节点
     */
    protected void expandNode(ContextNode node) {
        long tmp = timer.getTimeUsed();
        for (int i = node.attribute + 1; i < columnNum; i++) {
            if (schema.containAttribute(i)) {
                node.nextNodes.add(new ContextNode(node.context.addAttribute(i)));
            }
        }
        expandTime += timer.getTimeUsed() - tmp;
    }
}
