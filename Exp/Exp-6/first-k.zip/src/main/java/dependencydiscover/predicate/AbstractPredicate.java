package dependencydiscover.predicate;

public interface AbstractPredicate {

}
