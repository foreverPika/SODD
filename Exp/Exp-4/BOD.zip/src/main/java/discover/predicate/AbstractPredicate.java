package discover.predicate;

public interface AbstractPredicate {

}
