package discover.od;

import dataStructures.DataFrame;
import dataStructures.PartialDataFrame;
import dataStructures.fd.FDCandidate;
import dataStructures.od.AttributeAndDirection;
import dataStructures.od.ODCandidate;
import dataStructures.od.ODTree;
import dataStructures.od.ODTreeNodeEquivalenceClasses;
import discover.predicate.Operator;
import discover.predicate.SingleAttributePredicate;
import minimal.ODMinimalCheckTree;
import minimal.ODMinimalChecker;
import sampler.OneLevelCheckingSampler;
import sampler.Sampler;
import util.Timer;
import validator.lightWeight.FDLightVaildator;
import validator.od.ODPrefixBasedIncrementalValidator;
import validator.od.ODValidator;

import java.io.*;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BOD extends ODDiscoverer {

    protected Sampler sampler;
    protected ODValidator odValidator;
    protected FDLightVaildator fdLightVaildator;
    protected boolean printDebugInfo;
    private final static Set<CanonicalOD> result = new HashSet<>();

    private long totalDiscoverTime = 0;
    private long totalValidateTime = 0;
    private long totalProductTime = 0;
    private long totalCloneTime = 0;
    private long totalCheckTime = 0;
    private long totalMinimalTime = 0;

    private static Set<CanonicalOD> minOCDs;

    public BOD(Sampler sampler, ODValidator odValidator, boolean printDebugInfo) {
        this.sampler = sampler;
        this.odValidator = odValidator;
        this.printDebugInfo = printDebugInfo;
        this.fdLightVaildator = new FDLightVaildator();
    }


    @Override
    public ODTree discover(DataFrame data, ODTree reference) {
        System.out.println("数据集大小" + data.getRowCount() + "行" + data.getColumnCount() + "列");
        Timer timer = new Timer();
        ODTree odTree = new ODTree(data.getColumnCount());
        Timer sampleTimer = new Timer();

        PartialDataFrame sampledData = sampler.sample(data);
        System.out.println("抽样用时: " + sampleTimer.getTimeUsedAndReset() / 1000.0 + "s");
        System.out.println("抽样数量: " + sampledData.getRowCount());
        int round = 0;
        while (true) {
            round++;
            System.out.println("------");
            System.out.println("第" + round + "轮开始");
            Timer roundTimer = new Timer();
            int subRound = 0;
            BFSODDiscovererForIteration discoverer = new BFSODDiscovererForIteration();
            while (true) {
                subRound++;
                System.out.println("\n第" + subRound + "次迭代");
                Timer subtimer = new Timer();
                odTree = discoverer.discover(sampledData, odTree);
                totalDiscoverTime += subtimer.getTimeUsed();
                System.out.println("发现用时: " + subtimer.getTimeUsedAndReset() / 1000.0 + "s");
                System.out.println("OD数量: " + odTree.getAllOdsOrderByBFS().size());


                Set<FDCandidate> fds = discoverer.fdCandidates;
                Set<Integer> fdViolateRow = fdLightVaildator.validate(fds, data);
                System.out.println("**************");
                System.out.println("fds数量: " + fds.size());
                System.out.println("fdViolateRow: " + fdViolateRow);
                System.out.println("**************");


                Set<Integer> violateRowIndexes = odValidator.validate(odTree, data);
                violateRowIndexes.addAll(fdViolateRow);
                totalValidateTime += subtimer.getTimeUsed();
                System.out.println("检测用时: " + subtimer.getTimeUsedAndReset() / 1000.0 + "s");
                System.out.println("剩余OD数量: " + odTree.getAllOdsOrderByBFS().size());
                dealPartTime();
                if (violateRowIndexes.size() == 0) {
                    if (discoverer.isComplete()) {
                        System.out.println("------");
                        System.out.println("第" + round + "轮结束");
                        System.out.println("本轮用时" + roundTimer.getTimeUsed() / 1000 + "s");
                        System.out.println("新数据集大小" + sampledData.getRowCount());
                        System.out.println("------");
                        System.out.println("-----------------------------------------------------");
                        System.out.println("最终统计");
                        System.out.println("用时" + timer.getTimeUsed() / 1000.0 + "s");
                        System.out.println("OD数量" + odTree.getAllOdsOrderByBFS().size());
                        System.out.println("OD:" + odTree.getAllOdsOrderByBFS());
                        System.out.println("fds数量: " + fds.size());
                        System.out.println("数据集大小" + sampledData.getRowCount());
                        System.out.println("discover时间:" + totalDiscoverTime / 1000.0 + "s");
                        System.out.println("validate时间:" + totalValidateTime / 1000.0 + "s");

                        System.out.println("check时间:" + totalCheckTime / 1000.0 + "s");
                        System.out.println("minimal检查时间:" + totalMinimalTime / 1000.0 + "s");
                        System.out.println("product时间:" + totalProductTime / 1000.0 + "s");
                        System.out.println("clone时间:" + totalCloneTime / 1000.0 + "s");
                        System.out.println("-----------------------------------------------------");
                        return odTree;
                    } else {
                        System.out.println("violateRow size is 0 && discoverer is not complete");
                        if (odTree.getAllOdsOrderByDFS().size() > 10000000) {
                            for (ODCandidate od : odTree.getAllOdsOrderByBFS()) {
                                System.out.println("发现od超过10000000");
                                System.out.println(od);
                            }
                            return odTree;
                        }
                    }
                } else {
                    sampledData.addRows(violateRowIndexes);
                    System.out.println("------");
                    System.out.println("第" + round + "轮结束");
                    System.out.println("本轮用时" + roundTimer.getTimeUsed() / 1000.0 + "s");
                    System.out.println("新数据集大小" + sampledData.getRowCount());
                    System.out.println("------");
                    break;
                }
            }
        }
    }

    void dealPartTime() {
//        System.out.println("check时间 " + ODTreeNodeEquivalenceClasses.checkTime / 1000.0 + "s");
//        System.out.println("minimal检查时间 " + ODMinimalCheckTree.odMinimalCheckTime / 1000.0 + "s");
//        System.out.println("product时间 " + ODTreeNodeEquivalenceClasses.mergeTime / 1000.0 + "s");
//        System.out.println("clone时间 " + ODTreeNodeEquivalenceClasses.cloneTime / 1000.0 + "s");
        totalCheckTime += ODTreeNodeEquivalenceClasses.checkTime;
        totalMinimalTime += ODMinimalCheckTree.odMinimalCheckTime;
        totalProductTime += ODTreeNodeEquivalenceClasses.mergeTime;
        totalCloneTime += ODTreeNodeEquivalenceClasses.cloneTime;
        ODTreeNodeEquivalenceClasses.checkTime = 0;
        ODTreeNodeEquivalenceClasses.cloneTime = 0;
        ODTreeNodeEquivalenceClasses.mergeTime = 0;
        ODMinimalChecker.odMinimalCheckTime = 0;
    }

    @Override
    public ODTree discoverFD(DataFrame data, List<FDCandidate> fdCandidates) {
        return null;
    }

    public static Set<CanonicalOD> trans2SOD(List<ODCandidate> ods) {
        for (ODCandidate od : ods) {
            od2cod(od);
            od2ocd(od);
        }
        return result;
    }

    public static void od2cod(ODCandidate od) {
        List<AttributeAndDirection> left = od.leftAndRightAttributeList.left;
        List<AttributeAndDirection> right = od.leftAndRightAttributeList.right;
        AttributeSet context = new AttributeSet();
        for (AttributeAndDirection a : left) {
            context = context.addAttribute(a.attribute);
        }
        for (AttributeAndDirection a : right) {
            if (!context.containAttribute(a.attribute)) {
                CanonicalOD newod = new CanonicalOD(context, a.attribute);
                if(minOCDs.contains(newod)){
                    result.add(newod);
                }
            }
        }
    }

    public static void od2ocd(ODCandidate od) {
        List<AttributeAndDirection> left = od.leftAndRightAttributeList.left;
        List<AttributeAndDirection> right = od.leftAndRightAttributeList.right;
        for (int i = 0; i < left.size(); ++i) {
            for (int j = 0; j < right.size(); ++j) {
                od2ocdcontext(od, i, j);
            }
        }

    }

    public static void od2ocdcontext(ODCandidate od, int leftindex, int rightindex) {
        AttributeSet context = new AttributeSet();
        for (int i = 0; i < leftindex; ++i) {
            context = context.addAttribute(od.leftAndRightAttributeList.left.get(i).attribute);
        }
        for (int i = 0; i < rightindex; ++i) {
            context = context.addAttribute(od.leftAndRightAttributeList.right.get(i).attribute);
        }
        AttributeAndDirection left = od.leftAndRightAttributeList.left.get(leftindex);
        AttributeAndDirection right = od.leftAndRightAttributeList.right.get(rightindex);
        if (context.containAttribute(left.attribute) || context.containAttribute(left.attribute) || left.attribute == right.attribute) {
            return;
        }
        if (left.attribute > right.attribute) {
            AttributeAndDirection tmp = left;
            left = right;
            right = tmp;
        }
        if (left.direction == right.direction) {
            SingleAttributePredicate l = new SingleAttributePredicate(left.attribute, Operator.LESSEQUAL);
            CanonicalOD newod = new CanonicalOD(context, l, right.attribute);
            if(minOCDs.contains(newod)){
                result.add(newod);
            }
        } else {
            SingleAttributePredicate l = new SingleAttributePredicate(left.attribute, Operator.GREATEREQUAL);
            CanonicalOD newod = new CanonicalOD(context, l, right.attribute);
            if(minOCDs.contains(newod)){
                result.add(newod);
            }
        }
    }
    public static void writeToFile(Set<CanonicalOD> sodList, String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (CanonicalOD sod : sodList) {
                writer.write(sod.toString()); // 写入对象的字符串表示
                writer.newLine(); // 换行
            }
            System.out.println("数据已成功写入文件：" + filePath);
        } catch (IOException e) {
            System.err.println("写入文件时出错：" + e.getMessage());
        }
    }

    // 从文件读取CanonicalOD对象列表
    public static Set<CanonicalOD> readFromFile(String filePath) {
        Set<CanonicalOD> sodList = new HashSet<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // 这里需要根据CanonicalOD的具体实现解析字符串
                // 假设CanonicalOD有一个fromString方法将字符串转换为对象
                CanonicalOD sod = CanonicalOD.fromString(line);
                sodList.add(sod);
            }
            System.out.println("数据已成功从文件读取：" + filePath);
        } catch (IOException e) {
            System.err.println("读取文件时出错：" + e.getMessage());
        }
        return sodList;
    }

    public static void main(String[] args) {
        DataFrame dataFrame = DataFrame.fromCsv(args[0]);
        Timer timer = new Timer();
        ODTree discover = new BOD(
                new OneLevelCheckingSampler(),
                new ODPrefixBasedIncrementalValidator(),
                true).discover(dataFrame, null);
        timer.outTimeAndReset();
        List<ODCandidate> ods = discover.getAllOdsOrderByBFS();
        System.out.println("od数量:" + ods.size());
//        System.out.println(ods);

        // 写入文件
        String filePath = args[1];
//        writeToFile(sods, filePath);

        // 从文件读取
        BOD.minOCDs = readFromFile(filePath);
        System.out.println("all sod:" + BOD.minOCDs.size());

//        // 验证读取的数据
//        for (CanonicalOD sod : minOCDs) {
//            System.out.println("读取的对象: " + sod);
//        }

        Set<CanonicalOD> sods = trans2SOD(ods);
        System.out.println("lod to sod:" + sods.size());
        System.out.println("Ratio:" + (double)sods.size()/BOD.minOCDs.size());
//        System.out.println(sods);



    }
}
