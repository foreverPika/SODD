#!/bin/bash

datasets=(
    "DBLP-8M-13"
    "NCV-1M-19"
    "NCV-4M-19"
)

jar1="SODDL.jar"
output_file_SODDL="results_SODDL_long.txt"
> $output_file_SODDL

for dataset in "${datasets[@]}"; do
    csv_file="Data/long/${dataset}.csv"

    echo "Processing $csv_file with $jar1..."
    result1=$(java -Xms2g -Xmx80g -jar $jar1 $csv_file 10000000 0 1 1 1 1)
    echo "Jar: $jar1, Dataset: $csv_file, Result: $result1, 参数topk-1" >> $output_file_SODDL
    
    echo "Processing $csv_file with $jar1..."
    echo "参数k "
    result1=$(java -Xms2g -Xmx80g -jar $jar1 $csv_file 10000000 1 1 1 1 1)
    echo "Jar: $jar1, Dataset: $csv_file, Result: $result1, 参数topk-2" >> $output_file_SODDL

    echo "Processing $csv_file with $jar1..."
    echo "参数k "
    result1=$(java -Xms2g -Xmx80g -jar $jar1 $csv_file 10000000 2 1 1 1 1)
    echo "Jar: $jar1, Dataset: $csv_file, Result: $result1, 参数topk-3" >> $output_file_SODDL

    echo "Processing $csv_file with $jar1..."
    echo "参数k "
    result1=$(java -Xms2g -Xmx80g -jar $jar1 $csv_file 10000000 3 1 1 1 1)
    echo "Jar: $jar1, Dataset: $csv_file, Result: $result1, 参数topk-4" >> $output_file_SODDL

    echo "Processing $csv_file with $jar1..."
    echo "参数k "
    result1=$(java -Xms2g -Xmx80g -jar $jar1 $csv_file 10000000 4 1 1 1 1)
    echo "Jar: $jar1, Dataset: $csv_file, Result: $result1, 参数topk-5" >> $output_file_SODDL

    echo "Processing $csv_file with $jar1..."
    echo "参数maxFails "
    result1=$(java -Xms2g -Xmx80g -jar $jar1 $csv_file 10000000 1 1 1 1 2)
    echo "Jar: $jar1, Dataset: $csv_file, Result: $result1, 参数maxFails-2" >> $output_file_SODDL

    echo "Processing $csv_file with $jar1..."
    echo "参数maxFails "
    result1=$(java -Xms2g -Xmx80g -jar $jar1 $csv_file 10000000 1 1 1 1 3)
    echo "Jar: $jar1, Dataset: $csv_file, Result: $result1, 参数maxFails-3" >> $output_file_SODDL

    echo "Processing $csv_file with $jar1..."
    echo "参数maxFails "
    result1=$(java -Xms2g -Xmx80g -jar $jar1 $csv_file 10000000 1 1 1 1 4)
    echo "Jar: $jar1, Dataset: $csv_file, Result: $result1, 参数maxFails-4" >> $output_file_SODDL

    echo "Processing $csv_file with $jar1..."
    echo "参数maxFails "
    result1=$(java -Xms2g -Xmx80g -jar $jar1 $csv_file 10000000 1 1 1 1 5)
    echo "Jar: $jar1, Dataset: $csv_file, Result: $result1, 参数maxFails-5" >> $output_file_SODDL
done


echo "Datasets(long) processing completed. Results saved in $output_file_SODDL."
