package contexttree;

import soddml.AttributeSet;

import java.util.ArrayList;

public class ContextNode {
    public byte attribute;
    public AttributeSet context;
    public ArrayList<ContextNode> nextNodes;
    public byte isValid;//错误为0，正确为1，待验证为2

    public ContextNode() {
        context = new AttributeSet(0);
        nextNodes = new ArrayList<ContextNode>();
        isValid = 2;
        attribute = -1;
    }

    public ContextNode(AttributeSet newContext) {
        context = newContext;
        nextNodes = new ArrayList<ContextNode>();
        isValid = 2;
        attribute = (byte)this.context.getLastAttribute();
    }

    public void setIsValid(int isValid) {
        this.isValid = (byte) isValid;
    }
    public int getAttribute(){
        return attribute;
    }
}
