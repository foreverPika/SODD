package soddml;

import contexttree.OcdTree;

import java.util.HashSet;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class CoverAttribute {
    public AttributeSet attributeSet;
    public HashSet<OcdTree> coverTree;
    private final ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();
    private final ReentrantReadWriteLock.ReadLock readLock = rwLock.readLock();
    private final ReentrantReadWriteLock.WriteLock writeLock = rwLock.writeLock();
    public CoverAttribute(int columnNum){
        attributeSet = new AttributeSet();
        coverTree = new HashSet<>();
    }
    public boolean containAttribute(int attribute){
        try {
            readLock.lock();
            return attributeSet.containAttribute(attribute);
        } finally {
            readLock.unlock();
        }
    }
    public void addAttribute(int a,int b){
        try{
            writeLock.lock();
            attributeSet = attributeSet.addAttribute(a).addAttribute(b);
        }finally {
            writeLock.unlock();
        }
    }
    public void deleteAttribute(int a,int b){
        try{
            writeLock.lock();
            attributeSet = attributeSet.deleteAttribute(a).deleteAttribute(b);
        }finally {
            writeLock.unlock();
        }
    }
    public boolean containTree(OcdTree ocdTree){
        try{
            readLock.lock();
            return coverTree.contains(ocdTree);
        }finally {
            readLock.unlock();
        }
    }
    public void addTree(OcdTree ocdTree){
        try{
            writeLock.lock();
            coverTree.add(ocdTree);
        }finally {
            writeLock.unlock();
        }

    }
}
