package soddml;

import contexttree.*;
import dependencydiscover.dataframe.DataFrame;
import dependencydiscover.sampler.ClusterSampler;
import util.Gateway;
import pli.PLI;
import util.Timer;
import util.Util;

import java.io.IOException;
import java.util.*;
import java.util.concurrent.*;

public class SODDML {
    private final long timeLimit;
    private boolean complete = true;
//    private static Queue<ContextNode> queue = new LinkedList<>();
    private long validTime;
    private long findTime;
    private long fdFindTime;
    private long ocdFindTime;
    private long fdSampleTime;
    private int allOcdTreeNum;
    private long ocdFinishTime;
    private long fdFinishTime;
    private long testTime;
    private long sampleDiscoverTime;
    private int tupleNum;
    private int columnNum;
    private final Set<CanonicalOD> result = Collections.synchronizedSet(new HashSet<>());

    private AttributeSet schema;

    private DataFrame data;

    List<Integer> ocdViorows = new ArrayList<>();
    Set<Integer> viorows = new HashSet<>();

    ViorowsSet viorowsSet = new ViorowsSet();
    private double errorRateThreshold = -1f;

    Gateway traversalGateway;
    private boolean turn2Sample;
//    private int thisLevelNodes;
//    private int nextLevelNodes;

    Timer timer = new Timer();
    public long sampleTime;

    public SODDML(long timeLimit, double errorRateThreshold) {
        this.timeLimit = timeLimit;
        this.errorRateThreshold = errorRateThreshold;
    }

    public SODDML(long timeLimit) {
        this.timeLimit = timeLimit;
    }

    private boolean timeUp() {
        return timer.getTimeUsed() >= timeLimit;
    }

    public boolean isComplete() {
        return complete;
    }

    private AllOcdTree allOcdTree;
    private AllFdTree allFdTree;
    private int wrongNum;
    private int completeOcdTreeNum;
    private int completeFdTreeNum;

    private void initialize(DataFrame data, int tupleNum, int wrongNum) {
        traversalGateway = new Gateway.ComplexTimeGateway();
        this.viorows.clear();
        this.data = data;
        this.tupleNum = tupleNum;
        this.validTime = 0;
        this.findTime = 0;
        this.testTime = 0;
        this.completeOcdTreeNum = 0;
        this.sampleDiscoverTime = 0;
        this.fdFindTime = 0;
        this.ocdFindTime = 0;
        this.fdSampleTime = 0;
        this.turn2Sample = false;
        this.wrongNum = wrongNum;
//        this.thisLevelNodes = 0;
//        this.nextLevelNodes = 0;
        AttributeSet emptySet = new AttributeSet();
        schema = new AttributeSet();
        for (int i = 0; i < data.getColumnCount(); i++) {
            schema = schema.addAttribute(i);
        }
        this.columnNum = data.getColumnCount();
        allOcdTree = new AllOcdTree(columnNum, schema, data, 100);
        allFdTree = new AllFdTree(columnNum, schema, data);
        allOcdTreeNum = allOcdTree.allOcdTree.size();

    }

    public Set<CanonicalOD> discover(DataFrame data) {
        long firstTime = timer.getTimeUsed();
        //ocd
//        System.out.println();
        //采样发现
        long tmp;
        int newNonOcd = 0;
        int ocdnum = 1;
        do {
            int count = validateOcd();
            turn2Sample = false;
            ++ocdnum;
            tmp = timer.getTimeUsed();
            if (!viorowsSet.isEmpty()) {
                newNonOcd = allOcdTree.discoverFromVioSet(viorowsSet);
            }
            sampleDiscoverTime += timer.getTimeUsed() - tmp;
            viorows.clear();
            viorowsSet.clear();
        } while (!allOcdTree.isComplete());
        this.ocdFinishTime = timer.getTimeUsed();
//        System.out.println("totalTime:" + ocdFindTime + "ms");
//        System.out.println("all od:"+result.size());
        //fd
//        System.out.println();
        turn2Sample = false;
        int newNonFd = 0;
        int fdnum = 1;
        do {
            int count = validateFd();
            turn2Sample = false;
//            System.out.println("FdEpoch " + fdnum + " newOd:" + count + " beginNonFd:" + newNonFd);
            ++fdnum;
            tmp = timer.getTimeUsed();
            if (!viorowsSet.isEmpty()) {
                newNonFd = allFdTree.discoverFromVioSet(viorowsSet);
            }
            fdSampleTime += timer.getTimeUsed() - tmp;
            viorows.clear();
            viorowsSet.clear();
        } while (!allFdTree.isComplete());
        this.fdFinishTime = timer.getTimeUsed()-ocdFinishTime;
        //over
        System.out.println();
        if (isComplete()) {
            Util.out("HyODnew Finish");
        } else {
            Util.out("HyODnew Time Limited");
        }
        return result;
    }

    public int validateOcd() {//返回找到的ocd和fd的个数
        int count = 0;
        ExecutorService executor = Executors.newFixedThreadPool(8);
        List<Future<Integer>> futures = new ArrayList<>();
        Iterator<OcdTree> iterator = allOcdTree.allOcdTree.values().iterator();
        while (iterator.hasNext()) {
            OcdTree tree = iterator.next();
            if (tree.isComplete) {
                allOcdTree.ncover.remove(tree.ocd);
                iterator.remove();
                continue;
            }
            // 封装任务，确保两行代码按顺序执行
            Callable<Integer> task = () -> {
//                System.out.println("ocd:"+tree.ocd.left+"~"+(right+1));
                int res = 0;
                while(!tree.isComplete){
                    ViorowsSet threadViorowsSet = new ViorowsSet();
                    allOcdTree.addNonOcd(tree.ocd);
                    res+=validateTree(tree,threadViorowsSet);
                    allOcdTree.discoverFromVioSet(threadViorowsSet);
                }
                return res;
            };

            // 提交任务
            Future<Integer> future = executor.submit(task);
            futures.add(future);
        }

        // 统一获取任务结果
        for (Future<Integer> future : futures) {
            try {
                int validOd = future.get();
                count += validOd;
            } catch (InterruptedException | ExecutionException e) {
                e.printStackTrace();
            }
        }
        executor.shutdown();
        return count;
    }

    private int validateTree(OcdTree tree,ViorowsSet viorowsSet) {
        int count = 0;
        int thisLevelNodes = tree.thisLevelNodes;
        int nextLevelNodes = tree.nextLevelNodes;
        byte completeLevel = tree.completeLevel;
        Queue<ContextNode> queue = tree.q;
        if (queue.isEmpty()) {
            queue.offer(tree.root);
            ++thisLevelNodes;
        }
        while (!queue.isEmpty()) {
            //跳出验证机制
            if (viorowsSet.getSize() >= wrongNum) {
                tree.thisLevelNodes = thisLevelNodes;
                tree.nextLevelNodes = nextLevelNodes;
                tree.completeLevel = completeLevel;
                turn2Sample = true;
                return count;
            }
            ContextNode node = queue.poll();
            --thisLevelNodes;

            for (ContextNode nextNode : node.nextNodes) {
                queue.offer(nextNode);
                ++nextLevelNodes;
            }
            if(thisLevelNodes==0){
                thisLevelNodes = nextLevelNodes;
                nextLevelNodes = 0;
                ++completeLevel;
            }
            if (node.nextNodes.isEmpty() && node.isValid == 2) {//叶子节点且没验证
                validateNode(tree, node,viorowsSet);
            }
        }
        tree.completeLevel = completeLevel;
        tree.isComplete = true;

        return count;
    }

    private int validateNode(OcdTree tree, ContextNode node,ViorowsSet viorowsSet) {
        AttributeSet context = node.context;
        int left = tree.ocd.left.attribute;
        int right = tree.ocd.right;
        FdTree leftFdTree = allFdTree.allFdTree.get(left);
        FdTree rightFdTree = allFdTree.allFdTree.get(right);

        boolean leftFdFind = leftFdTree.findGeneration(context);
        boolean rightFdFind = rightFdTree.findGeneration(context);

        if (leftFdFind || rightFdFind) {
            node.isValid = 1;
            if (leftFdFind && !rightFdFind) {//给右树加候选
                if (rightFdTree.findContext(context) == 3) {
                    rightFdTree.addFD(context, 2);
                }
            } else if (!leftFdFind) {
                if (leftFdTree.findContext(context) == 3) {
                    leftFdTree.addFD(context, 2);
                }
            }
            return 0;
        }
        boolean ocdFind = tree.findGeneration(context);
        if (ocdFind) {
            node.isValid = 1;
            if (rightFdTree.findContext(context) == 3) {
                rightFdTree.addFD(context, 2);
            }
            if (leftFdTree.findContext(context) == 3) {
                leftFdTree.addFD(context, 2);
            }
            return 0;
        }


        //(3){context}:ocd
        CanonicalOD ocd = new CanonicalOD(context, tree.ocd.left, right);
        Map<Integer, Set<Integer>> addvio = ocd.validForSample(data, errorRateThreshold, false, tupleNum);
        if (!addvio.isEmpty()) {//ocd错误或者fd正确
            int res = 0;
            if (addvio.containsKey(-1)) {//context->left正确
                CanonicalOD od = new CanonicalOD(context, left);
                result.add(od);
                leftFdTree.addFD(context, 1);
                ++res;
                node.isValid = 1;
                addvio.remove(-1);
            }
            if (addvio.containsKey(-2)) {//context->right正确
                CanonicalOD od = new CanonicalOD(context, right);
                result.add(od);
                rightFdTree.addFD(context, 1);
                ++res;
                node.isValid = 1;
                addvio.remove(-2);
            }
            if (addvio.isEmpty()) {//fd正确
                return res;
            }
        }
        if (addvio.isEmpty()) {//{context}:left~right正确
            result.add(ocd);
            node.isValid = 1;
            for (int i = node.attribute + 1; i < columnNum; i++) {
                if (i == left) {
                    if (rightFdTree.findContext(context.addAttribute(i)) == 3) {
                        rightFdTree.addFD(context.addAttribute(i), 2);
                    }
                } else if (i == right) {
                    if (leftFdTree.findContext(context.addAttribute(i)) == 3) {
                        leftFdTree.addFD(context.addAttribute(i), 2);
                    }
                } else {
                    if (rightFdTree.findContext(context.addAttribute(i)) == 3) {
                        rightFdTree.addFD(context.addAttribute(i), 2);
                    }
                    if (leftFdTree.findContext(context.addAttribute(i)) == 3) {
                        leftFdTree.addFD(context.addAttribute(i), 2);
                    }
                }
            }
            return 1;
        }

        //fd和ocd都错误，扩展ocd的context
        viorowsSet.add(addvio);
        ocdViorows.clear();

        for (int i = node.attribute + 1; i < columnNum; ++i) {
            if (i != left && i != right) {
                ContextNode newNode = new ContextNode(node.context.addAttribute(i));
                node.nextNodes.add(newNode);
                tree.q.offer(newNode);
            }
        }
        node.isValid = 0;
        return 0;

    }

    public int validateFd() {//返回找到的fd的个数
        int count = 0;
        for (FdTree tree : allFdTree.allFdTree.values()) {
            if (tree.isComplete) {
//                if (tree.right == completeFdTreeNum) {
//                    completeFdTreeNum++;
//                    System.out.println("number:" + completeFdTreeNum + "/" + columnNum + "  " + tree.right + "  complete!!!!!!!!!!!!!!!!!!!!!");
//                    long endTime = this.timer.getTimeUsed();
//                    System.out.println("firstSampleTime:" + sampleTime + "ms, totalTime:" + (endTime + sampleTime) + "ms");
//                    System.out.println();
//                }
                continue;
            }
            count += validateFdTree(tree);
            if (turn2Sample) {
                return count;
            }
        }
        return count;
    }

    private int validateFdTree(FdTree tree) {
        int count = 0;
        Queue<ContextNode> fdqueue = new LinkedList<>();
        fdqueue.offer(tree.root);
        while (!fdqueue.isEmpty()) {
            //跳出验证机制
            if (viorowsSet.getSize() >= wrongNum) {
                turn2Sample = true;
                return count;
            }
            ContextNode node = fdqueue.poll();
            for (ContextNode nextNode : node.nextNodes) {//可换上层
                fdqueue.offer(nextNode);
            }
            if (node.nextNodes.isEmpty() && node.isValid == 2) {//叶子节点且没验证
                count += validateFdNode(tree, node);
            }

        }
        tree.isComplete = true;
        return count;
    }

    private int validateFdNode(FdTree tree, ContextNode node) {
        AttributeSet context = node.context;
        int right = tree.right;
        FdTree rightFdTree = allFdTree.allFdTree.get(right);
        if (rightFdTree.findGeneration(context)) {//找泛化
            node.isValid = 1;
            return 0;
        }
        CanonicalOD od = new CanonicalOD(context, right);
        Map<Integer, Set<Integer>> addvio = od.validForSample(data, errorRateThreshold, false, tupleNum);//验证

        if (addvio.isEmpty()) {//fd验证正确
            result.add(od);
            node.isValid = 1;
            return 1;
        }
        //fd验证错误
        node.isValid = 0;
        for (int i = node.attribute + 1; i < columnNum; i++) {
            if (i == right) {
                continue;
            }
            AttributeSet newContext = node.context.addAttribute(i);
            if (!tree.findGeneration(newContext) && !allFdTree.allFdTree.get(i).findGeneration(context)) {
                node.nextNodes.add(new ContextNode(newContext));
            }
        }
        viorowsSet.add(addvio);
        return 0;
    }

    public static void main(String[] args) throws IOException {
        DataFrame data = DataFrame.fromCsv(args[0], Integer.parseInt(args[1]));
        Runtime r = Runtime.getRuntime();
        PLI.setData(data);
        SODDML f = new SODDML(30000000, -1f);
        f.initialize(data, Integer.parseInt(args[2]), Integer.parseInt(args[3]));

        //采样
        Timer spTime = new Timer();
        ClusterSampler sampler = new ClusterSampler();
        int sampleNonOcd = sampler.firstSample(f.allOcdTree);
        System.out.println("sampleNonOcd:" + sampleNonOcd);
        f.sampleTime = spTime.getTimeUsed();

        f.discover(data);
        long endTime = f.timer.getTimeUsed();
        System.out.println(args[0]);
        System.out.println("firstSampleTime:" + f.sampleTime + "ms, totalTime:" + (endTime + f.sampleTime) + "ms");

        long startM = r.freeMemory();
        long endM = r.totalMemory();
        System.out.println("MemoryCost: " + String.valueOf((endM - startM) / 1024 / 1024) + "MB");
        System.out.println("all od:" + f.result.size());

        System.out.println();
        System.out.println("ocdFinishTime:" + f.ocdFinishTime + "ms, fdFinishTime:" + f.fdFinishTime + "ms");
        System.exit(0);
    }
}
