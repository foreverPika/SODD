package soddml;

public class DataAndDataAndIndex implements Comparable<DataAndDataAndIndex> {
    public long dataLeft;
    public long dataRight;
    public int index;

    @Override
    public int compareTo(DataAndDataAndIndex o) {
        return Long.compare(dataLeft,o.dataLeft);
    }

    @Override
    public String toString() {
        return "DataAndIndex{" +
                "dataLeft=" + dataLeft +
                "dataRight=" + dataRight +
                ", index=" + index +
                '}';
    }

    public DataAndDataAndIndex(long dataL, long dataR, int index) {
        this.dataLeft = dataL;
        this.dataRight = dataR;
        this.index = index;
    }
}
