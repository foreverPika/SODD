package contexttree;

import soddm.AttributeSet;
import util.Timer;

public class ContextTree {
    public ContextNode root;
    public AttributeSet schema;//构成context的全部属性
    public int columnNum;
    public util.Timer timer;
    public static long expandTime=0;
    public static long testTime = 0;
    public boolean isComplete;
    public byte completeLevel;

    public ContextTree(AttributeSet schema, int columnNum) {
        this.root = new ContextNode();
        this.schema = schema;
        this.columnNum = columnNum;
        this.timer = new Timer();
        this.isComplete = false;
        this.completeLevel = -1;
    }

    public int findContext2(AttributeSet context) {//找到准确的context，0为non，1为valid，2为待验证，3为不存在
        return findContext2(root, context);
    }

    private int findContext2(ContextNode root, AttributeSet context) {
        if (context.isEmpty()) {
            return root.isValid;
        }
        if (root.nextNodes.isEmpty()) {
            return 3;
        }
        int contextAttribute = context.getFirstAttribute();
        for (ContextNode contextNode : root.nextNodes) {
            if (contextNode.attribute == contextAttribute) {
                return findContext2(contextNode, context.deleteAttribute(contextAttribute));
            }
        }
        return 3;
    }

    public int addNonNode(AttributeSet context) {
        return addNonNodeNew(root,context);
    }
    private int addNonNodeNew(ContextNode root, AttributeSet context) {
        int count = 0;
        if (root.nextNodes.isEmpty()) {//下一个节点为空，就新建节点
            expandNode(root);
            ++count;
            root.isValid = 0;
        }
        if(context.isEmpty()){
            return count;
        }
        int firstAttribute = context.getFirstAttribute();
        //下一个节点不为空，访问节点
        for (ContextNode nextNode : root.nextNodes) {

            if (nextNode.attribute == firstAttribute) {//匹配到context的第一个属性
                context = context.deleteAttribute(firstAttribute);

                count += addNonNodeNew(nextNode, context);
                if(context.isEmpty()){
                    return count;
                }else{
                    firstAttribute = context.getFirstAttribute();
                }
            }//没有匹配到context的第一个属性，继续看下一个结点
        }
        return count;
    }



    /**
     * 扩展节点
     *
     * @param node 要扩展的节点
     */
    protected void expandNode(ContextNode node) {
        long tmp = timer.getTimeUsed();
        for (int i = node.attribute + 1; i < columnNum; i++) {
            if (schema.containAttribute(i)) {
                node.nextNodes.add(new ContextNode(node.context.addAttribute(i)));
            }
        }
        expandTime += timer.getTimeUsed() - tmp;
    }
}
