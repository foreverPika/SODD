package contexttree;

import soddm.AttributeSet;

import java.util.Comparator;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class FdTree extends ContextTree {
    public int right;
    private final ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();
    private final ReentrantReadWriteLock.ReadLock readLock = rwLock.readLock();
    private final ReentrantReadWriteLock.WriteLock writeLock = rwLock.writeLock();

    public FdTree(AttributeSet schema, int right, int columnNum) {
        super(schema, columnNum);
        this.right = right;
    }


    public int addNonFdNode(AttributeSet context){
        if(isComplete){
            return 0;
        }
        if(context.isEmpty()){
            if(root.isValid == 2){
                root.isValid =0;
                expandNode(root);
                return 1;
            }
            return 0;
        }
        return addNonFdNode2(root,context);
    }
    private int addNonFdNode2(ContextNode root,AttributeSet context) {
        int count = 0;
        if(root.nextNodes.isEmpty()){//后续节点为空
            if(root.isValid!=2){//叶子结点且已经验证
                return 0;
            }else{//叶子节点未验证，扩展
                root.isValid = 0;
                expandNode(root);
            }
        }
        //非叶子节点且context也不为空
        for(ContextNode node:root.nextNodes){
            int firstAttribute = context.getFirstAttribute();
            while (node.attribute > firstAttribute) {//nextnode:D context:ABCDE
                context = context.deleteAttribute(firstAttribute);
                if(context.isEmpty()){
                    return count;
                }
                firstAttribute = context.getFirstAttribute();
            }
            if (node.attribute == firstAttribute) {//匹配到context的第一个属性
                if(context.getSize() == 1){//命中最终节点
                    if(node.isValid == 2){
                        node.isValid = 0;
                        expandNode(node);
                        ++count;
                    }
                    return count;
                }else{//进入下一个结点
                    context = context.deleteAttribute(firstAttribute);
                    count+=addNonFdNode2(node,context);
                }
            }
            //<就下一个节点
        }

        return count;
    }
    public void addFD(AttributeSet context,int isValid) {//isValid为1则添加正确fd，为2则添加候选fd
        try{
            writeLock.lock();
            addFD2(root, context, isValid);
        }finally {
            writeLock.unlock();
        }

    }
    private void addFD2(ContextNode root, AttributeSet context, int isValid) {
        if (context.isEmpty()) {
            root.isValid = (byte) isValid;
//            if(isValid == 0){//isvalid是0就扩展节点
//                Set<Integer> s = new HashSet<>();
//                for(ContextNode nextNode:root.nextNodes){
//                    s.add(nextNode.attribute);
//                }
//                for (int i = root.attribute + 1; i < columnNum; i++) {
//                    if (schema.containAttribute(i)&&!s.contains(i)) {
//                        root.nextNodes.add(new ContextNode(root.context.addAttribute(i)));
//                    }
//                }
//                root.nextNodes.sort(Comparator.comparingInt(ContextNode::getAttribute));
//            }
            return;
        } else {
            root.isValid = 0;//路径设为non-fd
        }
        boolean flag = false;//标记是否在下一个结点中找到context的第一个属性
        int contextAttribute = context.getFirstAttribute();
        for (ContextNode contextNode : root.nextNodes) {
            if (contextNode.attribute == contextAttribute) {
                flag = true;
                addFD2(contextNode,context.deleteAttribute(contextAttribute),isValid);
                return;
            }
        }
        if(!flag){//没找到则新建结点访问
            root.nextNodes.add(new ContextNode(root.context.addAttribute(contextAttribute)));
            addFD2(root.nextNodes.get(root.nextNodes.size()-1),context.deleteAttribute(contextAttribute),isValid);
            root.nextNodes.sort(Comparator.comparingInt(ContextNode::getAttribute));
        }
    }
    public int findFD(AttributeSet context){
        return findContext2(context);
    }
    public int findContext(AttributeSet context){
        try {
            readLock.lock();
            return findContext2(context);
        }finally {
            readLock.unlock();
        }

    }

    public boolean findGeneration(AttributeSet context){//找context子集成立的fd是否存在
        try {
            readLock.lock();
            return findGeneration2(root,context);
        }finally {
            readLock.unlock();
        }

    }
    private boolean findGeneration2(ContextNode root,AttributeSet context){
        //叶子节点或context为空
        if(root.nextNodes.isEmpty()||context.isEmpty()){
            if(root.isValid == 1){
                return true;
            } else {
                return false;
            }
        }
        //非叶子节点
        int contextAttribute = context.getFirstAttribute();
        for(ContextNode nextNode:root.nextNodes) {
            while (nextNode.attribute > contextAttribute) {//nextnode:D context:ABCDE
                context = context.deleteAttribute(contextAttribute);
                if(context.isEmpty()){
                    return false;
                }
                contextAttribute = context.getFirstAttribute();
            }
            if (nextNode.attribute == contextAttribute) {
                boolean tmp = findGeneration2(nextNode, context.deleteAttribute(contextAttribute));
                if (tmp) {
                    return true;
                }
            }
            //<的情况可直接跳过到下一个节点
        }
        return false;
    }
}
