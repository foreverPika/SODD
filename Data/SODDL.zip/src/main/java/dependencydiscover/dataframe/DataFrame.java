package dependencydiscover.dataframe;

import util.Util;

import java.util.*;

public class DataFrame {
    protected List<List<Long>> data = new ArrayList<>();
    private List<String> columnNames = new ArrayList<>();

    public int getColumnCount() {
        return columnNames.size();
    }

    public int getTupleCount() {
        return data.size();
    }

    public long get(int row, int column) {
        return data.get(row).get(column);
    }

    public List<Long> getTuple(int tuple) {
        return data.get(tuple);
    }

    public void deleteRow(int row) {
        data.remove(row);
    }

    public void addTuple(List<Long> tuple) {
        data.add(tuple);
    }

    public List<String> getColumnNames() {
        return columnNames;
    }

    public void setColumnNames(List<String> columnNames) {
        this.columnNames = columnNames;
    }

    public int getRowCount() {
        return data.size();
    }

    public List<List<Long>> getData() {
        return this.data;
    }

    public List<Long> getRow(int row) {
        return data.get(row);
    }

    public static DataFrame fromCsv(String filePath, int maxTuples, double rowRate, double columnRate) {
        try {
            String[] lines = Util.fromFile(filePath).split("\n");
            DataFrame result = new DataFrame();

            // 处理列名
            String headerLine = lines[0];
            String[] allColumns = headerLine.split(",");

            // 计算需要保留的列数
            int columnCount = (int) Math.ceil(allColumns.length * columnRate);
            if (columnCount == 0) columnCount = 1; // 确保至少保留一列

            // 截取前columnRate比例的列名
            result.columnNames = Arrays.asList(Arrays.copyOfRange(allColumns, 0, columnCount));
            System.out.println("this file has " + lines.length + " lines.");

            // 计算需要保留的行数（包括标题行）
            int totalRows = lines.length;
            int tuplesNum = Math.min(
                    (int) Math.ceil((totalRows - 1) * rowRate) + 1, // +1 是因为要包含标题行
                    maxTuples
            );
            if (tuplesNum <= 1) tuplesNum = 2; // 确保至少有标题行和一行数据
            System.out.println("we will take " + (tuplesNum - 1) + " data lines.");
            System.out.println("we will take " + columnCount + " columns");
            // 处理数据行
            for (int i = 1; i < tuplesNum; i++) {
                String line = lines[i];
                List<Long> list = new ArrayList<>();
                String[] parts = line.split(",");

                // 只处理前columnRate比例的列
                int actualColumnCount = Math.min(parts.length, columnCount);
                for (int j = 0; j < actualColumnCount; j++) {
                    list.add(Long.parseLong(parts[j]));
                }

                // 填充缺失的列（如果有）
                while (list.size() < columnCount) {
                    list.add(null); // 假设DataFrame支持null值
                }

                if (list.size() != result.getColumnCount()) {
                    throw new RuntimeException(String.format(
                            "column count not fixed: expected: %d, actual: %d",
                            result.getColumnCount(), list.size()
                    ));
                }

                result.data.add(list);
            }

            return result;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    public static DataFrame fromCsv(String filePath, int maxTuples) {
        try {
            String[] lines = Util.fromFile(filePath).split("\n");
            DataFrame result = new DataFrame();
            String line = lines[0];
            String[] parts = line.split(",");
            result.columnNames = Arrays.asList(parts);
            System.out.println("this file has " + lines.length + "lines.");
            int tuplesNum = Math.min(lines.length,maxTuples);
            System.out.println("we will take " + tuplesNum + "lines.");


            for (int i = 1; i < tuplesNum; i++) {
                line = lines[i];
                List<Long> list = new ArrayList<>();
                parts = line.split(",");

                for (String part : parts) {
                    list.add(Long.parseLong(part));
                }
                if (list.size() != result.getColumnCount()) {
                    throw new RuntimeException(String.format("column count not fixed:expected: %d, actual:%d",
                            result.getColumnCount(), list.size()));
                }

                result.data.add(list);
            }
            return result;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

    }

    public String toAString() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < columnNames.size(); i++) {
            if (i != 0)
                sb.append(',');
            sb.append(columnNames.get(i));
        }
        for (List<Long> line : data) {
            sb.append('\n');
            for (int i = 0; i < line.size(); i++) {
                if (i != 0)
                    sb.append(',');
                sb.append(line.get(i));
            }
        }
        return sb.toString();
    }

    public void toCsv(String filePath) {
        Util.toFile(toAString(), filePath);
    }

    public DataFrame chooseColumns(Set<Integer> columnIndexes) {
        DataFrame result = new DataFrame();

        boolean[] choose = new boolean[getColumnCount()];
        int originalColumnCount = getColumnCount();
        for (Integer columnIndex : columnIndexes) {
            if (columnIndex >= 1 && columnIndex <= originalColumnCount)
                choose[columnIndex - 1] = true;
        }

        List<String> newColumnName = new ArrayList<>();
        for (int i = 0; i < originalColumnCount; i++) {
            if (choose[i]) {
                newColumnName.add(columnNames.get(i));
            }
        }
        result.columnNames = newColumnName;

        List<List<Long>> newData = new ArrayList<>();
        for (List<Long> originalRow : data) {
            List<Long> newRow = new ArrayList<>();
            for (int i = 0; i < originalColumnCount; i++) {
                if (choose[i]) {
                    newRow.add(originalRow.get(i));
                }
            }
            newData.add(newRow);
        }
        result.data = newData;
        return result;
    }

    public DataFrame randomSelectColumns(int columnCount) {
        if (columnCount > getColumnCount() || columnCount < 0) {
            return this;
        }
        List<Integer> columns = new ArrayList<>();
        for (int column = 1; column <= getColumnCount(); column++) {
            columns.add(column);
        }
        Collections.shuffle(columns);
        Set<Integer> columnToChoose = new HashSet<>();
        for (int i = 0; i < columnCount; i++) {
            columnToChoose.add(columns.get(i));
        }
        chooseColumns(columnToChoose);
        return this;
    }

    public interface ThreeIntegerConsumer {
        int consume(int tuple, int column, int randomResult);
    }

    public boolean tupleEqual(int tuple1, int tuple2) {
        for (int attribute = 0; attribute < getColumnCount(); attribute++) {
            if (get(tuple1, attribute) != get(tuple2, attribute))
                return false;
        }
        return true;
    }

    public boolean tupleEqual(int tuple1, int tuple2, Collection<Integer> attributes) {
        for (Integer attribute : attributes) {
            if (get(tuple1, attribute) != get(tuple2, attribute))
                return false;
        }
        return true;
    }

    public DataFrame getSubDataFrameFromFirstTuplesAndColumns(int countTuple, int countColumn) {
        Set<Integer> preservedTuples = new HashSet<>();
        for (int i = 0; i < countTuple; i++) {
            preservedTuples.add(i);
        }
        Set<Integer> preservedColumns = new HashSet<>();
        for (int i = 0; i < countColumn; i++) {
            preservedColumns.add(i);
        }
        return getSubDataFrame(preservedTuples, preservedColumns);
    }

    public DataFrame getRandomSubDataFrame(int countTuple, int countColumn) {
        if (countTuple > getTupleCount()) {
            countTuple = getTupleCount();
        }
        if (countColumn > getColumnCount()) {
            countColumn = getColumnCount();
        }
        if (countTuple == getTupleCount() && countColumn == getColumnCount()) {
            return this;
        }
        Set<Integer> preservedTuples = new HashSet<>(Util.randomSample(getTupleCount(), countTuple));
        Set<Integer> preservedColumns = new HashSet<>(Util.randomSample(getColumnCount(), countColumn));
        return getSubDataFrame(preservedTuples, preservedColumns);
    }

    public DataFrame getSubDataFrame(Set<Integer> preservedTuples, Set<Integer> preservedColumns) {
        DataFrame result = new DataFrame();
        for (int column = 0; column < columnNames.size(); column++) {
            if (preservedColumns.contains(column)) {
                result.columnNames.add(columnNames.get(column));
            }
        }
        for (int tuple = 0; tuple < getTupleCount(); tuple++) {
            if (!preservedTuples.contains(tuple)) {
                continue;
            }
            List<Long> newTuple = new ArrayList<>();
            for (int column = 0; column < getColumnCount(); column++) {
                if (preservedColumns.contains(column)) {
                    newTuple.add(data.get(tuple).get(column));
                }
            }
            result.data.add(newTuple);
        }
        return result;
    }

}
